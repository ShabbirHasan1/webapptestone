(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["npm.bootstrap-vue-dc08d8f1"],{7386:function(n,e,a){"use strict";a.d(e,"a",(function(){return d})),a.d(e,"b",(function(){return u})),a.d(e,"c",(function(){return c})),a.d(e,"d",(function(){return o}));var t=a("fc39"),d=Object(t["a"])("Blank",""),u=Object(t["a"])("Dash",'<path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8z"/>'),c=Object(t["a"])("PersonFill",'<path fill-rule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>'),o=Object(t["a"])("Plus",'<path fill-rule="evenodd" d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>');
/*!
 * BootstrapVue Icons, generated from Bootstrap Icons 1.2.1
 *
 * @link https://icons.getbootstrap.com/
 * @license MIT
 * https://github.com/twbs/icons/blob/master/LICENSE.md
 */}}]);